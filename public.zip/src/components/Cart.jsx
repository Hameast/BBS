import React from 'react'

const Cart = () => {
  return (
    <div>
      <hr></hr>
    </div>
  )
}

export default Cart
