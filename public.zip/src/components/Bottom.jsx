import React from 'react'

const Bottom = () => {
  return (
    <div>
      <hr />
      <h3>Copyright 2024. 함동균 All rights reserved.</h3>
    </div>
  )
}

export default Bottom
