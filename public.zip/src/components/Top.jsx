import React from 'react'

const Top = () => {
  return (
    <div>
      <img src='http://via.placeholder.com/960x150' width="100%"/>
    </div>
  )
}

export default Top
